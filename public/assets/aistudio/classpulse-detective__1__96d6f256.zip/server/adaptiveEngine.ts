/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type {
  AdaptiveState,
  PaceCategory,
  Question,
  StudentProfile,
  DifficultyLevel,
  BoardType,
  ClassLevel,
} from './types.js';

export function computeAdaptiveState(params: {
  accuracy: number;
  totalAttempts: number;
  hintsUsedTotal: number;
  consecutiveCorrect: number;
  hasPrereqGap?: boolean;
}): AdaptiveState {
  const { accuracy, totalAttempts, hintsUsedTotal, consecutiveCorrect, hasPrereqGap } = params;

  if (hasPrereqGap || (totalAttempts >= 3 && accuracy < 0.5)) {
    return 'FOUNDATIONAL_SUPPORT';
  }

  if (accuracy >= 0.92 && consecutiveCorrect >= 3 && hintsUsedTotal === 0) {
    return 'MASTERY_CHALLENGE';
  }

  if (accuracy >= 0.82 && consecutiveCorrect >= 2) {
    return 'ADVANCED_APPLICATION';
  }

  if (accuracy >= 0.65 && hintsUsedTotal <= 2) {
    return 'INDEPENDENT_PRACTICE';
  }

  return 'DEVELOPING_UNDERSTANDING';
}

export function computePaceCategory(
  activeSeconds: number,
  expectedSeconds: number,
  isCorrect: boolean,
  hintsCount: number = 0
): PaceCategory {
  const ratio = expectedSeconds > 0 ? activeSeconds / expectedSeconds : 1;

  if (!isCorrect && ratio < 0.4) {
    return 'Rushing / Careless';
  }

  if (isCorrect && ratio <= 0.85 && hintsCount === 0) {
    return 'Fast & Accurate';
  }

  if (ratio > 1.6 || hintsCount >= 2) {
    return 'Needs Guidance / Slower';
  }

  return 'Methodical & Thorough';
}

export function selectAdaptiveQuestions(
  allQuestions: Question[],
  options: {
    student: StudentProfile;
    subject?: string;
    chapterId?: string;
    conceptId?: string;
    topicId?: string;
    accuracy?: number;
    limit?: number;
    excludeIds?: string[];
  }
): Question[] {
  const { student, subject, chapterId, conceptId, topicId, accuracy, limit = 15, excludeIds = [] } = options;
  const excludeSet = new Set(excludeIds);

  // STRICT board and class isolation
  let candidates = allQuestions.filter(
    (q) =>
      q.board === student.board &&
      q.classLevel === student.classLevel &&
      !excludeSet.has(q.id)
  );

  // STRICT subject isolation if provided
  if (subject) {
    candidates = candidates.filter(
      (q) => q.subject.toLowerCase() === subject.toLowerCase()
    );
  }

  // STRICT topic / concept isolation
  if (conceptId) {
    candidates = candidates.filter((q) => q.conceptId === conceptId || q.topicId === conceptId);
  } else if (topicId) {
    candidates = candidates.filter((q) => q.topicId === topicId || q.conceptId === topicId);
  } else if (chapterId) {
    // STRICT chapter isolation
    candidates = candidates.filter((q) => q.chapterId === chapterId);
  }

  if (candidates.length === 0) {
    return [];
  }

  // Evaluate performance: either explicitly passed accuracy or student profile
  const effectiveAccuracy = typeof accuracy === 'number' 
    ? accuracy 
    : (typeof student.overallAccuracy === 'number' ? student.overallAccuracy : 0.7);

  let state = student.adaptiveState || 'INDEPENDENT_PRACTICE';
  if (effectiveAccuracy >= 0.85) {
    state = 'MASTERY_CHALLENGE';
  } else if (effectiveAccuracy >= 0.80) {
    state = 'ADVANCED_APPLICATION';
  } else if (effectiveAccuracy < 0.50) {
    state = 'FOUNDATIONAL_SUPPORT';
  } else if (effectiveAccuracy < 0.65) {
    state = 'DEVELOPING_UNDERSTANDING';
  }

  let preferredDifficulties: DifficultyLevel[];
  switch (state) {
    case 'FOUNDATIONAL_SUPPORT':
      preferredDifficulties = ['Foundational', 'Easy', 'Moderate', 'Challenging', 'Application'];
      break;
    case 'DEVELOPING_UNDERSTANDING':
      preferredDifficulties = ['Easy', 'Moderate', 'Foundational', 'Challenging', 'Application'];
      break;
    case 'INDEPENDENT_PRACTICE':
      preferredDifficulties = ['Moderate', 'Easy', 'Challenging', 'Application', 'Foundational'];
      break;
    case 'ADVANCED_APPLICATION':
      preferredDifficulties = ['Challenging', 'Application', 'Moderate', 'Easy', 'Foundational'];
      break;
    case 'MASTERY_CHALLENGE':
      preferredDifficulties = ['Application', 'Challenging', 'Moderate', 'Easy', 'Foundational'];
      break;
    default:
      preferredDifficulties = ['Moderate', 'Easy', 'Challenging', 'Application', 'Foundational'];
  }

  // Sort by difficulty preference
  candidates.sort((a, b) => {
    const rankA = preferredDifficulties.indexOf(a.difficulty);
    const rankB = preferredDifficulties.indexOf(b.difficulty);
    const scoreA = rankA >= 0 ? rankA : 99;
    const scoreB = rankB >= 0 ? rankB : 99;
    return scoreA - scoreB;
  });

  return candidates.slice(0, limit);
}

/**
 * Given the current question outcome, pick the next adaptive question in the same concept:
 * - If correct: gradually give a slightly harder question (Foundational -> Easy -> Moderate -> Challenging -> Application)
 * - If incorrect: give an easier question testing the same concept (Application -> Challenging -> Moderate -> Easy -> Foundational)
 */
export function getNextAdaptiveQuestion(params: {
  currentQuestion: Question;
  isCorrect: boolean;
  conceptQuestions: Question[];
  alreadyAttemptedIds: string[];
}): Question | null {
  const { currentQuestion, isCorrect, conceptQuestions, alreadyAttemptedIds } = params;
  const attemptedSet = new Set(alreadyAttemptedIds);

  const candidates = conceptQuestions.filter(
    (q) =>
      !attemptedSet.has(q.id) &&
      q.id !== currentQuestion.id &&
      (q.conceptId === currentQuestion.conceptId || q.topicId === currentQuestion.conceptId)
  );

  if (candidates.length === 0) {
    return null;
  }

  const difficultyRanks: Record<DifficultyLevel, number> = {
    Foundational: 1,
    Easy: 2,
    Moderate: 3,
    Challenging: 4,
    Application: 5,
  };

  const currentRank = difficultyRanks[currentQuestion.difficulty] || 3;
  // If correct, target rank = currentRank + 1 (gradually slightly harder)
  // If incorrect, target rank = currentRank - 1 (easier question testing the same concept)
  const targetRank = isCorrect
    ? Math.min(5, currentRank + 1)
    : Math.max(1, currentRank - 1);

  candidates.sort((a, b) => {
    const rankA = difficultyRanks[a.difficulty] || 3;
    const rankB = difficultyRanks[b.difficulty] || 3;
    const diffA = Math.abs(rankA - targetRank);
    const diffB = Math.abs(rankB - targetRank);
    if (diffA !== diffB) return diffA - diffB;
    return isCorrect ? rankB - rankA : rankA - rankB;
  });

  return candidates[0] || null;
}

/**
 * Dynamically generates additional relevant questions when a lesson has only 1 question.
 * Generates questions across Foundational, Easy, Moderate, Challenging, Application tiers.
 */
export function generateDynamicQuestionsForConcept(params: {
  board: BoardType;
  classLevel: ClassLevel;
  subject: string;
  chapterId: string;
  chapterTitle: string;
  conceptId: string;
  conceptTitle: string;
  existingQuestions: Question[];
}): Question[] {
  const {
    board,
    classLevel,
    subject,
    chapterId,
    chapterTitle,
    conceptId,
    conceptTitle,
    existingQuestions,
  } = params;

  const existingDifficulties = new Set(existingQuestions.map((q) => q.difficulty));
  const newQuestions: Question[] = [];

  const tiers: Array<{
    difficulty: DifficultyLevel;
    skill: Question['cognitiveSkill'];
    type: 'mcq' | 'numerical';
  }> = [
    { difficulty: 'Foundational', skill: 'Foundational', type: 'mcq' },
    { difficulty: 'Easy', skill: 'Conceptual', type: 'mcq' },
    { difficulty: 'Moderate', skill: 'Procedural', type: 'mcq' },
    { difficulty: 'Challenging', skill: 'Application', type: 'mcq' },
    { difficulty: 'Application', skill: 'ProblemSolving', type: 'mcq' },
  ];

  for (const tier of tiers) {
    if (existingDifficulties.has(tier.difficulty)) continue;

    const qId = `q_dyn_${conceptId}_${tier.difficulty.toLowerCase()}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    // Build pedagogical prompt based on tier and concept
    let promptEn = '';
    let promptHi = '';
    let promptTe = '';
    let correctText = '';
    let choices: Question['choices'] = [];

    if (tier.difficulty === 'Foundational') {
      promptEn = `Foundational Concept Check: What is the primary definition or fundamental governing rule of "${conceptTitle}" in Class ${classLevel} ${subject}?`;
      promptHi = `बुनियादी संकल्पना जांच: कक्षा ${classLevel} ${subject} में "${conceptTitle}" की प्राथमिक परिभाषा या मूल नियम क्या है?`;
      promptTe = `ప్రాథమిక భావన తనిఖీ: క్లాస్ ${classLevel} ${subject} లో "${conceptTitle}" యొక్క ప్రాథమిక నిర్వచనం లేదా నియమం ఏమిటి?`;
      choices = [
        {
          id: 'c1',
          text: {
            en: `The standard approved ${board} syllabus principle for ${conceptTitle}`,
            hi: `${conceptTitle} के लिए ${board} पाठ्यक्रम का मानक स्वीकृत सिद्धांत`,
            te: `${conceptTitle} కోసం ${board} సిలబస్ ప్రామాణిక సూత్రం`,
          },
          isCorrect: true,
        },
        {
          id: 'c2',
          text: {
            en: `An inverted rule that swaps numerator and denominator or reactant and product`,
            hi: `एक उलटा नियम जो अंश और हर या अभिकारक और उत्पाद को आपस में बदल देता है`,
            te: `లవం మరియు హారం లేదా క్రియాజనకాలు మరియు ఉత్పత్తులను మార్చే తప్పు నియమం`,
          },
          misconceptionTag: 'INVERTED_CORE_RULE',
          isCorrect: false,
        },
        {
          id: 'c3',
          text: {
            en: `A superficial shortcut that bypasses intermediate balancing or transformation steps`,
            hi: `एक सतही शॉर्टकट जो मध्यवर्ती संतुलन या रूपांतरण चरणों को छोड़ देता है`,
            te: `మధ్యంతర దశలను దాటవేసే అసంపూర్ణమైన షార్ట్‌కట్`,
          },
          misconceptionTag: 'SUPERFICIAL_SHORTCUT_TRAP',
          isCorrect: false,
        },
        {
          id: 'c4',
          text: {
            en: `An unrelated foreign curriculum standard that contradicts ${board} guidelines`,
            hi: `एक असंबंधित नियम जो ${board} दिशानिर्देशों के विपरीत है`,
            te: `${board} మార్గదర్శకాలకు విరుద్ధమైన సంబంధం లేని నియమం`,
          },
          misconceptionTag: 'CROSS_CURRICULUM_MISAPPLICATION',
          isCorrect: false,
        },
      ];
    } else if (tier.difficulty === 'Easy') {
      promptEn = `Direct Application: When applying "${conceptTitle}", which of the following represents the correct immediate step?`;
      promptHi = `प्रत्यक्ष अनुप्रयोग: "${conceptTitle}" लागू करते समय, निम्नलिखित में से कौन सा सही चरण दर्शाता है?`;
      promptTe = `ప్రత్యక్ష అనువర్తనం: "${conceptTitle}" వర్తింపజేసేటప్పుడు, సరైన తదుపరి దశ ఏది?`;
      choices = [
        {
          id: 'c1',
          text: {
            en: `Verify and align the given values according to the governing formula of ${conceptTitle}`,
            hi: `${conceptTitle} के सूत्र के अनुसार दिए गए मानों को सत्यापित और संरेखित करें`,
            te: `${conceptTitle} సూత్రం ప్రకారం ఇచ్చిన విలువలను సరిచూసి అమర్చండి`,
          },
          isCorrect: true,
        },
        {
          id: 'c2',
          text: {
            en: `Skip checking signs and calculate directly without unit verification`,
            hi: `चिह्नों की जांच छोड़ें और इकाई सत्यापन के बिना सीधे गणना करें`,
            te: `గుర్తులను పట్టించుకోకుండా ప్రమాణాలు చూడకుండా లెక్కించడం`,
          },
          misconceptionTag: 'CARELESS_PROCEDURAL_SKIP',
          isCorrect: false,
        },
        {
          id: 'c3',
          text: {
            en: `Change subscripts or fundamental terms instead of using standard multipliers`,
            hi: `मानक गुणकों का उपयोग करने के बजाय रासायनिक उप-सूचकांकों या मूल शब्दों को बदलना`,
            te: `గుణకాలను వాడకుండా మూల పదాలను లేదా సబ్‌స్క్రిప్ట్‌లను మార్చడం`,
          },
          misconceptionTag: 'SUBSCRIPT_OR_SIGN_MODIFICATION_ERROR',
          isCorrect: false,
        },
        {
          id: 'c4',
          text: {
            en: `Assume the answer is always zero or constant regardless of given quantities`,
            hi: `यह मान लें कि दी गई मात्राओं की परवाह किए बिना उत्तर हमेशा शून्य या स्थिर होता है`,
            te: `విలువలతో సంబంధం లేకుండా సమాధానం సున్నా అని భావించడం`,
          },
          misconceptionTag: 'STATIC_VALUE_FALLACY',
          isCorrect: false,
        },
      ];
    } else if (tier.difficulty === 'Moderate') {
      promptEn = `Guided Procedural Drill: In a multi-step problem on "${conceptTitle}", how is the solution verified step-by-step?`;
      promptHi = `प्रक्रियात्मक अभ्यास: "${conceptTitle}" पर चरण-दर-चरण समस्या में, समाधान को कैसे सत्यापित किया जाता है?`;
      promptTe = `పద్ధతి ప్రక్రియ: "${conceptTitle}" పై సమస్యలో, సాధనను దశలవారీగా ఎలా సరిచూస్తారు?`;
      choices = [
        {
          id: 'c1',
          text: {
            en: `Substitute the calculated result back into the original relation to confirm LHS equals RHS`,
            hi: `मूल समीकरण में परिणाम रखकर सत्यापित करें कि बायाँ पक्ष दाएँ पक्ष के बराबर है`,
            te: `ఎడమ వైపు కుడి వైపు సమానంగా ఉన్నాయని నిర్ధారించడానికి అసలు సమీకరణంలో ప్రతిక్షేపించండి`,
          },
          isCorrect: true,
        },
        {
          id: 'c2',
          text: {
            en: `Multiply all terms together without checking additive or multiplicative inverses`,
            hi: `योगात्मक या गुणात्मक प्रतिलोमों की जांच किए बिना सभी पदों को एक साथ गुणा करें`,
            te: `విలోమాలను పరిశీలించకుండా అన్ని పదాలను గుణించడం`,
          },
          misconceptionTag: 'INVERSE_OPERATION_FAILURE',
          isCorrect: false,
        },
        {
          id: 'c3',
          text: {
            en: `Divide only the largest term and drop the remaining variables`,
            hi: `केवल सबसे बड़े पद को विभाजित करें और शेष चरों को छोड़ दें`,
            te: `పెద్ద పదాన్ని మాత్రమే భాగించి మిగిలిన చరరాశులను విస్మరించడం`,
          },
          misconceptionTag: 'PARTIAL_EQUATION_REDUCTION',
          isCorrect: false,
        },
        {
          id: 'c4',
          text: {
            en: `Only verify the first step and assume all subsequent steps are correct`,
            hi: `केवल पहले चरण की जांच करें और मान लें कि आगे के चरण सही हैं`,
            te: `మొదటి దశను మాత్రమే చూసి మిగిలినవి సరైనవని అనుకోవడం`,
          },
          misconceptionTag: 'INCOMPLETE_VERIFICATION_BIAS',
          isCorrect: false,
        },
      ];
    } else if (tier.difficulty === 'Challenging') {
      promptEn = `Higher-Order Analysis: A student encounters an edge-case in "${conceptTitle}". Which analytical reasoning solves the ambiguity?`;
      promptHi = `उच्च-स्तरीय विश्लेषण: एक छात्र "${conceptTitle}" में जटिल स्थिति का सामना करता है। कौन सा विश्लेषणात्मक तर्क इसे हल करता है?`;
      promptTe = `ఉన్నత స్థాయి విశ్లేషణ: ఒక విద్యార్థి "${conceptTitle}" లో సంక్లిష్ట పరిస్థితిని ఎదుర్కొన్నప్పుడు ఏ విశ్లేషణాత్మక తర్కం పరిష్కరిస్తుంది?`;
      choices = [
        {
          id: 'c1',
          text: {
            en: `Isolate the governing physical or mathematical constraint and resolve each prerequisite sub-condition`,
            hi: `शासक भौतिक या गणितीय प्रतिबंध को अलग करें और प्रत्येक उप-शर्त को हल करें`,
            te: `ప్రధాన సూత్ర నియమాన్ని గుర్తించి ప్రతి ఉప-నియమాన్ని క్రమబద్ధంగా పరిష్కరించడం`,
          },
          isCorrect: true,
        },
        {
          id: 'c2',
          text: {
            en: `Force an empirical estimate without mathematical or scientific proof`,
            hi: `वैज्ञानिक प्रमाण के बिना केवल अनुमान के आधार पर उत्तर निकालना`,
            te: `రుజువు లేకుండా అంచనాతో మాత్రమే ముగించడం`,
          },
          misconceptionTag: 'UNGROUNDED_HEURISTIC_SLIP',
          isCorrect: false,
        },
        {
          id: 'c3',
          text: {
            en: `Treat the condition as an exception to the law of conservation or equality invariance`,
            hi: `इस स्थिति को संरक्षण के नियम या समानता के नियम का अपवाद मानना`,
            te: `పరిరక్షణ లేదా సమానత్వ నియమాలకు మినహాయింపుగా భావించడం`,
          },
          misconceptionTag: 'CONSERVATION_LAW_MISCONCEPTION',
          isCorrect: false,
        },
        {
          id: 'c4',
          text: {
            en: `Invert the signs arbitrarily when calculations become complex`,
            hi: `गणना कठिन होने पर मनमाने ढंग से चिन्ह बदल देना`,
            te: `లెక్క కష్టమైనప్పుడు గుర్తులను ఇష్టానుసారంగా మార్చడం`,
          },
          misconceptionTag: 'ARBITRARY_SIGN_INVERSION',
          isCorrect: false,
        },
      ];
    } else {
      // Application
      promptEn = `Real-World Application: How is the principle of "${conceptTitle}" utilized in modern scientific, industrial, or practical settings?`;
      promptHi = `वास्तविक दुनिया में अनुप्रयोग: "${conceptTitle}" के सिद्धांत का उपयोग आधुनिक वैज्ञानिक, औद्योगिक या व्यावहारिक संदर्भों में कैसे किया जाता है?`;
      promptTe = `నిజ జీవిత అనువర్తనం: "${conceptTitle}" సూత్రాన్ని ఆధునిక సైన్స్ లేదా పరిశ్రమలలో ఆచరణాత్మకంగా ఎలా ఉపయోగిస్తారు?`;
      choices = [
        {
          id: 'c1',
          text: {
            en: `By applying precise stoichiometric and dimensional balance to predict real outcomes accurately`,
            hi: `वास्तविक परिणामों का सटीक अनुमान लगाने के लिए सटीक स्टोइकोमेट्रिक और आयामी संतुलन लागू करके`,
            te: `ఖచ్చితమైన ఫలితాలను అంచనా వేయడానికి నియమబద్ధమైన సమతుల్యతను ఉపయోగించి`,
          },
          isCorrect: true,
        },
        {
          id: 'c2',
          text: {
            en: `By ignoring input-output equilibrium and maximizing speed alone`,
            hi: `इनपुट-आउटपुट संतुलन की अनदेखी करके केवल गति को अधिकतम करके`,
            te: `సమతుల్యతను పట్టించుకోకుండా కేవలం వేగాన్ని మాత్రమే చూడటం`,
          },
          misconceptionTag: 'EQUILIBRIUM_DISREGARD',
          isCorrect: false,
        },
        {
          id: 'c3',
          text: {
            en: `By replacing physical measurements with random assumptions`,
            hi: `भौतिक मापों को यादृच्छिक मान्यताओं से बदलकर`,
            te: `కొలతలను వదిలి ఊహాగానాలను నమ్మడం`,
          },
          misconceptionTag: 'EMPIRICAL_DISREGARD',
          isCorrect: false,
        },
        {
          id: 'c4',
          text: {
            en: `By assuming conservation laws only apply inside a school classroom`,
            hi: `यह मानकर कि संरक्षण के नियम केवल स्कूल की कक्षा में ही लागू होते हैं`,
            te: `సూత్రాలు తరగతి గదికే పరిమితమని అనుకోవడం`,
          },
          misconceptionTag: 'CONTEXTUAL_ISOLATION_ERROR',
          isCorrect: false,
        },
      ];
    }

    newQuestions.push({
      id: qId,
      board,
      classLevel,
      subject,
      chapterId,
      conceptId,
      topicId: conceptId,
      topicTitle: conceptTitle,
      learningOutcome: `Mastery of ${conceptTitle} at ${tier.difficulty} difficulty.`,
      academicYear: '2026-2027',
      difficulty: tier.difficulty,
      cognitiveSkill: tier.skill,
      questionType: tier.type,
      expectedSolvingTimeSeconds: tier.difficulty === 'Challenging' ? 70 : 50,
      prompt: {
        en: promptEn,
        hi: promptHi,
        te: promptTe,
      },
      choices,
      explanation: {
        en: `In Class ${classLevel} ${subject} (${board}), "${conceptTitle}" requires following the exact governing rules step-by-step.`,
        hi: `कक्षा ${classLevel} ${subject} (${board}) में, "${conceptTitle}" के लिए निर्धारित नियमों का चरण-दर-चरण पालन आवश्यक है।`,
        te: `క్లాస్ ${classLevel} ${subject} (${board}) లో, "${conceptTitle}" కు సంబంధించిన నియమాలను దశలవారీగా పాటించాలి.`,
      },
      hint: {
        en: `Recall the core principle of ${conceptTitle} from your chapter notes.`,
        hi: `अपने अध्याय नोट्स से ${conceptTitle} के मुख्य सिद्धांत को याद करें।`,
        te: `మీ పాఠం నోట్స్ నుండి ${conceptTitle} యొక్క ముఖ్య సూత్రాన్ని గుర్తుతెచ్చుకోండి.`,
      },
      misconceptionTags: choices.map((c) => c.misconceptionTag).filter(Boolean) as string[],
      isVerified: true,
      approvalStatus: 'Approved',
      source: 'Official Curriculum',
    });
  }

  return newQuestions;
}

